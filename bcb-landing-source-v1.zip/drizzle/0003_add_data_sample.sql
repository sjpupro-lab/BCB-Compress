ALTER TABLE `leads` ADD `dataSample` text;
