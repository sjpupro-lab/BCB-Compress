# BCB Landing — Cloudflare Workers + D1

A static landing page (`/`) plus a separate tester application page (`/apply`)
served from a single Cloudflare Worker. Form submissions are stored in a
Cloudflare D1 database. There is **no savings calculator** — the page collects a
packet sample and you measure compression offline, then reply by email.

## Layout

```
src/worker.ts      Worker: serves static assets + POST /api/lead -> D1
src/landing.tsx    Landing page (entry: index.html)
src/apply.tsx      Application form, opens in a new window (entry: apply.html)
src/bcbContent.tsx Bilingual (KO/EN) copy + logo
src/index.css      Styles
migrations/        D1 schema (SQLite)
wrangler.jsonc     Worker config (ASSETS + D1 bindings, observability)
```

## One-time setup

```bash
# 1. Install deps
pnpm install            # or: npm install

# 2. Log in to Cloudflare
npx wrangler login

# 3. Create the D1 database, then paste the printed database_id into wrangler.jsonc
npx wrangler d1 create bcb-leads
#   -> copy "database_id": "..." into the d1_databases block in wrangler.jsonc

# 4. Create the leads table on the REMOTE database
npx wrangler d1 migrations apply bcb-leads --remote

# 5. (optional) owner notification webhook (Slack/Discord incoming webhook URL)
npx wrangler secret put NOTIFY_WEBHOOK_URL
```

## Deploy

```bash
npm run deploy          # vite build  ->  wrangler deploy
```

Wrangler uploads the Worker and the built `dist/` assets together. To attach a
custom domain, add a Custom Domain/route to the Worker in the Cloudflare
dashboard (Workers & Pages → your worker → Settings → Domains & Routes).

## Local development

```bash
npm run db:migrate:local   # create the table in the local D1
npm run preview            # wrangler dev (local Worker + assets + D1)
# open http://127.0.0.1:8787  and  http://127.0.0.1:8787/apply
```

## Reading leads

```bash
npx wrangler d1 execute bcb-leads --remote \
  --command "SELECT created_at, email, company, use_case, data_sample FROM leads ORDER BY created_at DESC LIMIT 50;"
```

`data_sample` is a JSON array of `{type, label, value}` items the applicant added
via the dropdown.

## API

`POST /api/lead`

```json
{
  "email": "you@company.com",
  "company": "Acme IoT",
  "useCase": "IoT",
  "lang": "KO",
  "dataItems": [
    { "type": "int_telemetry", "label": "정수 텔레메트리", "value": "0x1A2B" }
  ]
}
```

Response: `{ "ok": true, "id": "<uuid>" }` on success, or `{ "ok": false, "error": "..." }`
with a 4xx/5xx status. `email` is the only required field.

## Notes on the migration from the old stack

This project **replaces** the previous Node/tRPC + MySQL (Drizzle) server. The
savings-estimate backend (`savings.ts`, the result page, `computeSavings`,
`getResult`/`requestConsult`) is intentionally **not carried over** — it no longer
exists. The old `server/` directory can be archived or deleted.
