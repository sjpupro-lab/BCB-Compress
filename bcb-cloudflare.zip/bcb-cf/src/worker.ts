/**
 * BCB landing Worker.
 *
 * Responsibilities:
 *  1. Serve the built static site (landing + apply form) via the ASSETS binding.
 *  2. Handle POST /api/lead — store a tester application in D1 and (optionally)
 *     notify the owner through a webhook.
 *
 * There is intentionally no savings calculator here: the page collects a packet
 * sample and we measure compression offline, then reply by email.
 */

interface Env {
  /** Static assets (Vite build output in ./dist). */
  ASSETS: Fetcher;
  /** D1 database holding tester leads. */
  DB: D1Database;
  /** Optional outbound webhook (Slack/Discord/etc). Set via `wrangler secret put`. */
  NOTIFY_WEBHOOK_URL?: string;
}

interface DataItem {
  type: string;
  label: string;
  value: string;
}

interface LeadPayload {
  email: string;
  company?: string;
  useCase?: string;
  dataItems?: DataItem[];
  lang?: "EN" | "KO";
}

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const JSON_HEADERS = {
  "Content-Type": "application/json; charset=utf-8",
  "X-Content-Type-Options": "nosniff",
} as const;

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: JSON_HEADERS });
}

/** Trim a string and cap its length; returns null for empty input. */
function clean(v: unknown, max: number): string | null {
  if (typeof v !== "string") return null;
  const s = v.trim();
  if (!s) return null;
  return s.length > max ? s.slice(0, max) : s;
}

/** Validate and normalize the incoming data items, capping count and size. */
function normalizeItems(input: unknown): DataItem[] {
  if (!Array.isArray(input)) return [];
  return input
    .slice(0, 50)
    .map((raw) => {
      const o = (raw ?? {}) as Record<string, unknown>;
      return {
        type: clean(o.type, 64) ?? "",
        label: clean(o.label, 64) ?? "",
        value: clean(o.value, 2000) ?? "",
      };
    })
    .filter((i) => i.value !== "");
}

async function handleLead(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
  if (request.method !== "POST") {
    return json({ ok: false, error: "Method not allowed" }, 405);
  }

  let payload: LeadPayload;
  try {
    payload = (await request.json()) as LeadPayload;
  } catch {
    return json({ ok: false, error: "Invalid JSON body" }, 400);
  }

  const email = clean(payload.email, 320);
  if (!email || !EMAIL_RE.test(email)) {
    return json({ ok: false, error: "A valid email is required" }, 400);
  }

  const company = clean(payload.company, 255);
  const useCase = clean(payload.useCase, 64);
  const lang = payload.lang === "KO" ? "KO" : "EN";
  const items = normalizeItems(payload.dataItems);
  const dataSample = items.length ? JSON.stringify(items) : null;

  const id = crypto.randomUUID();
  const createdAt = new Date().toISOString();

  try {
    await env.DB.prepare(
      `INSERT INTO leads (id, created_at, email, company, use_case, data_sample, lang, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'new')`,
    )
      .bind(id, createdAt, email, company, useCase, dataSample, lang)
      .run();
  } catch (err) {
    console.error("[lead] D1 insert failed:", err);
    return json({ ok: false, error: "Storage error" }, 500);
  }

  // Fire-and-forget owner notification (non-blocking, non-fatal).
  if (env.NOTIFY_WEBHOOK_URL) {
    const lines = [
      `[BCB 테스터] ${company || email} 신청 (${useCase || "-"})`,
      `• 이메일: ${email}`,
      `• 회사: ${company || "-"}`,
      `• 용도: ${useCase || "-"}`,
      `• 데이터 항목: ${items.length ? items.map((i) => `${i.label}=${i.value}`).join(", ") : "(없음)"}`,
      `• 언어: ${lang} · ${createdAt}`,
      `리드 ID: ${id}`,
    ];
    const text = lines.join("\n");
    ctx.waitUntil(
      fetch(env.NOTIFY_WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        // `text` is for Slack-style webhooks, `content` for Discord-style.
        body: JSON.stringify({ text, content: text }),
      }).catch((err) => console.warn("[lead] notify failed:", err)),
    );
  }

  return json({ ok: true, id });
}

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/api/lead") {
      return handleLead(request, env, ctx);
    }
    if (url.pathname.startsWith("/api/")) {
      return json({ ok: false, error: "Not found" }, 404);
    }

    // Everything else: static assets (landing + apply form).
    return env.ASSETS.fetch(request);
  },
} satisfies ExportedHandler<Env>;
